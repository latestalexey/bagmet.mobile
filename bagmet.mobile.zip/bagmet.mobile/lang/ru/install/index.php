<?
$MESS["SCOM_INSTALL_NAME"] = "Интернет-магазин мобильных телефонов и планшетов";
$MESS["SCOM_INSTALL_DESCRIPTION"] = "Мастер создания интернет-магазина мобильных телефонов и планшетов";
$MESS["SCOM_INSTALL_TITLE"] = "Установка модуля";
$MESS["SCOM_UNINSTALL_TITLE"] = "Удаление модуля";
$MESS["SPER_PARTNER"] = "Веб-студия Багмет Михаила";
$MESS["PARTNER_URI"] = "";
?>