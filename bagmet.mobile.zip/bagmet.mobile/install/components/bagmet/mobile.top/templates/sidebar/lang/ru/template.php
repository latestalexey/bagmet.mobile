<?
$MESS["CATALOG_COMPARE"] = "Добавить в сравнение";
$MESS["CATALOG_IN_COMPARE"] = "Сравнить";
$MESS["CATALOG_ADD"] = "Купить";
$MESS["CATALOG_ADD_TITLE"] = "Добавить товар в корзину";
$MESS["CATALOG_MORE"] = "Подробнее";
$MESS["CR_TITLE_SALELEADER"] = "Хиты продаж";
$MESS["CR_TITLE_NEWPRODUCT"] = "Новинки";
$MESS["CR_TITLE_SPECIALOFFER"] = "Спецпредложения";
$MESS["CR_TITLE_NULL"] = "У вас нет ни одного товара, обладающего данным свойством.<br> Для того чтобы добавить товару свойство, необходимо отредактировать подходящий для этого товар и установить соответствующий флажок";
$MESS["CR_PRICE_OT"] = "от&nbsp;";
$MESS["CATALOG_SUBSCRIBE"] = "Сообщить о поступлении";
$MESS["CATALOG_IN_SUBSCRIBE"] = "Подписан";
$MESS["CATALOG_IN_CART"] = "В корзине";
$MESS["CATALOG_ADD_TO_CART"] = "Добавить в корзину";
$MESS["CATALOG_IN_CART_DELAY"] = "Отложен";
$MESS["CATALOG_OFFER_NAME"] = "Название";
$MESS["EMPTY_VALUE_SKU"] = "Не задано";
$MESS["CATALOG_NOT_AVAILABLE"] = "Отсутствует";
$MESS["CATALOG_NOT_AVAILABLE2"] = "Нет в наличии";
$MESS["CATALOG_CHOOSE"] = "Выберите";
?>