<?
$MESS["IBLOCK_MODULE_NOT_INSTALLED"] = "The Information Blocks module is not installed.";
$MESS["CATALOG_ERROR2BASKET"] = "Error adding product to cart.";
$MESS["IBLOCK_ERROR"] = "Information block is not specified.";
?>