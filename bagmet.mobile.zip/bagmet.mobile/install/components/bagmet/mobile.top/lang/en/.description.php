<?
$MESS["T_IBLOCK_DESC_CR_LIST"] = "Top Catalog Items";
$MESS["T_IBLOCK_DESC_CR_DESC"] = "Shows items with best values of selected properties.";
$MESS["T_IBLOCK_DESC_CATALOG"] = "Catalog";
?>