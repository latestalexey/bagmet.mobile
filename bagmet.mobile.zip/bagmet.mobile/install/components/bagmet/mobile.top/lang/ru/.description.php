<?
$MESS["T_IBLOCK_DESC_CR_LIST"] = "Top элементов каталога";
$MESS["T_IBLOCK_DESC_CR_DESC"] = "Показывает TOP элементов, обладающих заданным свойством (используется как правило на главной странице сайта)";
$MESS["T_IBLOCK_DESC_CATALOG"] = "Каталог";
?>