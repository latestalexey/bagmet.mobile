<?
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Модуль Информационных блоков не установлен";
$MESS ['CATALOG_ERROR2BASKET'] = "Ошибка добавления товара в корзину";
$MESS ['IBLOCK_ERROR'] = "Не выбран инфоблок";
?>
