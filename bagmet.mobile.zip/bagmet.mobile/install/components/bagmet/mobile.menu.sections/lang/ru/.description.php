<?
$MESS ['T_IBLOCK_DESC_MENU_ITEMS'] = "Пункты меню (каталоги)";
$MESS ['T_IBLOCK_DESC_MENU_ITEMS_DESC'] = "Дополнение меню названиями торговых каталогов и секций";
$MESS ['MAIN_NAVIGATION_SERVICE'] = "Навигация";
?>