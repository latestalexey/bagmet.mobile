<?
$MESS["T_IBLOCK_DESC_MENU_ITEMS"] = "Menu Items (catalogs)";
$MESS["T_IBLOCK_DESC_MENU_ITEMS_DESC"] = "Adds the titles of commercial catalogs and sections to the menu.";
$MESS["MAIN_NAVIGATION_SERVICE"] = "Navigation";
?>