<?
$MESS ['IBLOCK_TYPE'] = "Тип инфо-блока";
$MESS ['IBLOCK_IBLOCK'] = "Инфо-блок";
$MESS ['IBLOCK_SORT_ASC'] = "по возрастанию";
$MESS ['IBLOCK_SORT_DESC'] = "по убыванию";
$MESS ['IBLOCK_ELEMENT_COUNT'] = "Количество выводимых элементов";
$MESS ['IBLOCK_ELEMENT_SORT_FIELD'] = "По какому полю сортируем элементы";
$MESS ['IBLOCK_ELEMENT_SORT_ORDER'] = "Порядок сортировки элементов";
?>