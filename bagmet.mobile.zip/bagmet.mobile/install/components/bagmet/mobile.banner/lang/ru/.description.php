<?
$MESS ['SHOES_MAIN_PAGE_TEMPLATE_NAME'] = "Баннер для магазина обуви";
$MESS ['SHOES_MAIN_PAGE_TEMPLATE_DESCRIPTION'] = "Показывает изображения баннера";
$MESS ['T_SHOES_BANNER'] = "Баннер";
?>