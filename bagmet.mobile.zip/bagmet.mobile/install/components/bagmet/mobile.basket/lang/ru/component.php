<?
$MESS['SALE_MODULE_NOT_INSTALL']="Модуль Интернет-магазин не установлен.";
$MESS ['SALE_EMPTY_BASKET'] = "Ваша корзина пуста";
$MESS ['SBB_TITLE'] = "Моя корзина";
?>