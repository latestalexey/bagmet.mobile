<?
$MESS["SBB_DESC_YES"] = "Да";
$MESS["SBB_DESC_NO"] = "Нет";
$MESS["SBB_PATH_TO_ORDER"] = "Страница оформления заказа";
$MESS["SBB_HIDE_COUPON"] = "Спрятать поле ввода купона";
$MESS["SBB_COLUMNS_LIST"] = "Выводимые колонки";
$MESS["SBB_BNAME"] = "Название товара";
$MESS["SBB_BPROPS"] = "Свойства товара";
$MESS["SBB_BPRICE"] = "Цена";
$MESS["SBB_BTYPE"] = "Тип цены";
$MESS["SBB_BQUANTITY"] = "Количество";
$MESS["SBB_BDELETE"] = "Удалить";
$MESS["SBB_BDELAY"] = "Отложить";
$MESS["SBB_BWEIGHT"] = "Вес";
$MESS["SBB_BDISCOUNT"] = "Скидка";
$MESS["SBB_WEIGHT_UNIT"] = "Единица веса";
$MESS["SBB_WEIGHT_UNIT_G"] = "г";
$MESS["SBB_WEIGHT_KOEF"] = "Коэффициент единицы к грамму";
$MESS["SBB_QUANTITY_FLOAT"] = "Использовать дробное значение количества";
$MESS["SBB_VAT_SHOW_VALUE"] = "Отображать значение НДС";
$MESS["SBB_VAT_INCLUDE"] = "Включать НДС в цену";
$MESS["SBB_COUNT_DISCOUNT_4_ALL_QUANTITY"] = "Рассчитывать скидку для каждой позиции (на все количество товара)";
$MESS["SOF_COUNT_DISCOUNT_4_ALL_QUANTITY"] = "Рассчитывать скидку для каждой позиции (на все количество товара)";
?>