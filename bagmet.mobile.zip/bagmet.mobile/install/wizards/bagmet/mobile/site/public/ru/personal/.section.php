<?
$sSectionName = "Мой кабинет";
$arDirProperties = array(

);
?>