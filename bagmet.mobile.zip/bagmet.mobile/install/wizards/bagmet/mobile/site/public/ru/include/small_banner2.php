<div class="catalog_banner">
	<a href="<?=SITE_DIR?>catalog/samsung/samsung_i9300_galaxy_s_iii_lafleur_white/" class="small_banner" style="background-image: url('<?=SITE_DIR?>include/images/banner_small_2.jpg');"></a>
</div>