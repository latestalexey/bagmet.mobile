<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Контакты");
?>
<div class="page_wrapper">
	<h4 class="auth_form_title">Как нас найти?</h4>
	<p><b>Телефон:</b> 8 (495) 999 22 22<br>
	<b>Адрес:</b> г. Москва, пр-т. Серебрякова, д. 3</p>
	<!--<iframe width="700" height="500" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.ru/maps?f=q&amp;source=s_q&amp;hl=ru&amp;geocode=&amp;q=%D1%83%D0%BB.+%D0%9A%D0%BE%D1%81%D0%BC%D0%BE%D0%BD%D0%B0%D0%B2%D1%82%D0%B0+%D0%9B%D0%B5%D0%BE%D0%BD%D0%BE%D0%B2%D0%B0,+49%D0%B0,+%D0%9A%D0%B0%D0%BB%D0%B8%D0%BD%D0%B8%D0%BD%D0%B3%D1%80%D0%B0%D0%B4&amp;aq=t&amp;sll=54.729901,20.481354&amp;sspn=0.007422,0.01929&amp;t=m&amp;ie=UTF8&amp;hq=&amp;hnear=%D1%83%D0%BB.+%D0%9A%D0%BE%D1%81%D0%BC%D0%BE%D0%BD%D0%B0%D0%B2%D1%82%D0%B0+%D0%9B%D0%B5%D0%BE%D0%BD%D0%BE%D0%B2%D0%B0,+49,+%D0%9A%D0%B0%D0%BB%D0%B8%D0%BD%D0%B8%D0%BD%D0%B3%D1%80%D0%B0%D0%B4,+236022&amp;ll=54.731113,20.484781&amp;spn=0.01239,0.034332&amp;z=15&amp;iwloc=A&amp;output=embed"></iframe><br /><small><a href="https://maps.google.ru/maps?f=q&amp;source=embed&amp;hl=ru&amp;geocode=&amp;q=%D1%83%D0%BB.+%D0%9A%D0%BE%D1%81%D0%BC%D0%BE%D0%BD%D0%B0%D0%B2%D1%82%D0%B0+%D0%9B%D0%B5%D0%BE%D0%BD%D0%BE%D0%B2%D0%B0,+49%D0%B0,+%D0%9A%D0%B0%D0%BB%D0%B8%D0%BD%D0%B8%D0%BD%D0%B3%D1%80%D0%B0%D0%B4&amp;aq=t&amp;sll=54.729901,20.481354&amp;sspn=0.007422,0.01929&amp;t=m&amp;ie=UTF8&amp;hq=&amp;hnear=%D1%83%D0%BB.+%D0%9A%D0%BE%D1%81%D0%BC%D0%BE%D0%BD%D0%B0%D0%B2%D1%82%D0%B0+%D0%9B%D0%B5%D0%BE%D0%BD%D0%BE%D0%B2%D0%B0,+49,+%D0%9A%D0%B0%D0%BB%D0%B8%D0%BD%D0%B8%D0%BD%D0%B3%D1%80%D0%B0%D0%B4,+236022&amp;ll=54.731113,20.484781&amp;spn=0.01239,0.034332&amp;z=15&amp;iwloc=A" style="color:#666;text-align:left;font-size:13px;">Просмотреть увеличенную карту</a></small>-->
	<iframe width="100%" height="500" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.ru/maps?f=q&amp;source=s_q&amp;hl=ru&amp;geocode=&amp;q=%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0,+%D0%BF%D1%80%D0%BE%D0%B5%D0%B7%D0%B4+%D0%A1%D0%B5%D1%80%D0%B5%D0%B1%D1%80%D1%8F%D0%BA%D0%BE%D0%B2%D0%B0&amp;aq=0&amp;oq=%D0%BF%D1%80&amp;sll=55.853252,37.61869&amp;sspn=0.020138,0.066047&amp;t=h&amp;ie=UTF8&amp;hq=&amp;hnear=%D0%BF%D1%80.+%D0%A1%D0%B5%D1%80%D0%B5%D0%B1%D1%80%D1%8F%D0%BA%D0%BE%D0%B2%D0%B0,+%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0&amp;ll=55.849927,37.651777&amp;spn=0.024091,0.059996&amp;z=14&amp;iwloc=A&amp;output=embed"></iframe><br /><small><a href="https://maps.google.ru/maps?f=q&amp;source=embed&amp;hl=ru&amp;geocode=&amp;q=%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0,+%D0%BF%D1%80%D0%BE%D0%B5%D0%B7%D0%B4+%D0%A1%D0%B5%D1%80%D0%B5%D0%B1%D1%80%D1%8F%D0%BA%D0%BE%D0%B2%D0%B0&amp;aq=0&amp;oq=%D0%BF%D1%80&amp;sll=55.853252,37.61869&amp;sspn=0.020138,0.066047&amp;t=h&amp;ie=UTF8&amp;hq=&amp;hnear=%D0%BF%D1%80.+%D0%A1%D0%B5%D1%80%D0%B5%D0%B1%D1%80%D1%8F%D0%BA%D0%BE%D0%B2%D0%B0,+%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0&amp;ll=55.849927,37.651777&amp;spn=0.024091,0.059996&amp;z=14&amp;iwloc=A" style="color:#0000FF;text-align:left">Просмотреть увеличенную карту</a></small>
	<br><br><br>
	<h4 class="auth_form_title">Задайте нам вопрос</h4>
	<p>Мы всегда рады общению с нашими клиентами. Если у вас есть какие-либо пожелания, предложения, замечания, касающиеся работы нашего Интернет-магазина - пишите нам, и мы с благодарностью примем ваше мнение во внимание:</p>


<?$APPLICATION->IncludeComponent(
	"bitrix:main.feedback",
	"",
	Array(
		"USE_CAPTCHA" => "Y",
		"OK_TEXT" => "Спасибо, ваше сообщение принято.",
		"EMAIL_TO" => "sale@localhost",
		"REQUIRED_FIELDS" => array(),
		"EVENT_MESSAGE_ID" => array()
	),
false
);?>
</div>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php")?>