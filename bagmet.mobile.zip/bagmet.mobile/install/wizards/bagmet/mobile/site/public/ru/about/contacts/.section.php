<?
$sSectionName = "Контакты";
$arDirProperties = array(
);
?>