<?
$sSectionName = "Каталог";
$arDirProperties = array(

);
?>