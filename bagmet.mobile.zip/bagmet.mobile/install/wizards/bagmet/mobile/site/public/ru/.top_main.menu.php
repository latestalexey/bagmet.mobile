<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$aMenuLinks = Array(
	Array(
		"Доставка", 
		"about/delivery/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"О магазине", 
		"about/", 
		Array(), 
		Array(), 
		"" 
	),	
	Array(
		"Гарантия", 
		"about/guaranty/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Контакты",
		"about/contacts/",
		Array(),
		Array(),
		""
	),
	Array(
		"Мой кабинет",
		"personal/",
		Array(),
		Array(),
		"CUser::IsAuthorized()"
	),
);
?>