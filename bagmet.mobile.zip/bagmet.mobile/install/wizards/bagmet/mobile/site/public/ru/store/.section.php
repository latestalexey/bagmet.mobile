<?
$sSectionName = "Склады";
$arDirProperties = array(
);
?>