<?
$sSectionName = "Подписка";
$arDirProperties = array(

);
?>