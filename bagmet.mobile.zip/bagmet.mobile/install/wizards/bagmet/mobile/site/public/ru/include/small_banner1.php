<div class="catalog_banner">
	<a href="<?=SITE_DIR?>catalog/samsung/samsung_gt_i9250_galaxy_nexus_titanium_silver/" class="small_banner" style="background-image: url('<?=SITE_DIR?>include/images/banner_small_1.jpg');"></a>
</div>