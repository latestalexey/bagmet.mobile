<?
$sSectionName = "Обзоры";
$arDirProperties = Array(

);
?>