<?
$sSectionName = "Мои заказы";
$arDirProperties = array(

);
?>