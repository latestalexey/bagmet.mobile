<?
$MESS["THEME_DEFAULT"] = "Стандартная";
?>