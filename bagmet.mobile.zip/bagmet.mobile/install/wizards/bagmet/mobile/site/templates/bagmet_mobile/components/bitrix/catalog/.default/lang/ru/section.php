<?
$MESS["CATALOG_BUY"] = "Купить";
$MESS["CATALOG_SUBSCRIBE"] = "Сообщить о<br/>поступлении";
$MESS["CHOOSE_PARAMS"] = "Выберите параметры";
$MESS["CLOSE_POPUP"] = "Продолжить покупки";
$MESS['SECT_SORT_LABEL'] = 'Сортировать по';
$MESS['SECT_SORT_date'] = 'Новинкам';
$MESS['SECT_SORT_name'] = 'Названию';
$MESS['SECT_SORT_price'] = 'Цене';
$MESS['SECT_SORT_shows'] = 'Популярности';
?>