<?
$MESS ['CT_BSAC_CONFIRM'] = "Подтвердить";
$MESS ['CT_BSAC_LOGIN'] = "Логин";
$MESS ['CT_BSAC_CONFIRM_CODE'] = "Код подтверждения";
?>