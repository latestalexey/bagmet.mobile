<?
$MESS["SEARCH_GO"] = "Suchen";
$MESS["CT_BSP_ADDITIONAL_PARAMS"] = "Zusдtzliche Suchparameter";
$MESS["CT_BSP_KEYBOARD_WARNING"] = "Die Sprache der Suchanfrage wurde fьr die \"#query#\" gewechselt";
?>