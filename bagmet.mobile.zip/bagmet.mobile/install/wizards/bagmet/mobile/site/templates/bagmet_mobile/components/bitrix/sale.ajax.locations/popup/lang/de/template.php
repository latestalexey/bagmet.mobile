<?
$MESS["PUP_NULL"] = "Geben Sie eine Stadt ein";
?>