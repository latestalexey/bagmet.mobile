<?
$MESS["THEME_DEFAULT"] = "Желтая";
?>