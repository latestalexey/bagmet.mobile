<?
$MESS['YOUR_CART'] = 'Корзина (#NUM#)';
$MESS['YOUR_CART_EMPTY'] = 'Корзина';
?>