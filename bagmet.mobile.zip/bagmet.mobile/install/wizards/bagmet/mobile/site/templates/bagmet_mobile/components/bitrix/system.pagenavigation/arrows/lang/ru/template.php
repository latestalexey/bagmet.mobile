<?
$MESS["nav_prev"]="Назад";
$MESS["nav_paged"]="По стр.";
$MESS["pages"]="Страницы:";
$MESS["nav_next"]="Вперед";
$MESS["nav_all"]="Все";
?>