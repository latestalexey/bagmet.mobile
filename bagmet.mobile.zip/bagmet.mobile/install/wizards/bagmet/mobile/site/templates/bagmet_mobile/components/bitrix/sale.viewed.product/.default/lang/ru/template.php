<?
$MESS ['SBB_TITLE'] = "Оформление заказа";
$MESS ['VIEW_HEADER'] = "Вы смотрели";
$MESS ['PRODUCT_BUY'] = "Купить";
$MESS ['PRODUCT_BUSKET'] = "В корзину";
$MESS ['PRODUCT_VIEW'] = "Смотреть";
?>