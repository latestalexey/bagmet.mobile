<?
$MESS["S_PHONE"] = "тел:";
$MESS["S_SCHEDULE"] = "график:";
?>
