<?
$MESS["SEARCH_TITLE"] = "Поиск";
?>