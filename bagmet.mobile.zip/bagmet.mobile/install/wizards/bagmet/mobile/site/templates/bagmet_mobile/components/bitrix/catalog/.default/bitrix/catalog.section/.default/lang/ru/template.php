<?
$MESS["CATALOG_BUY"] = "Купить";
$MESS["CATALOG_VIEW"] = "Смотреть";
$MESS["CATALOG_COMPARE"] = "Добавить в сравнение";
$MESS["CATALOG_COMPARE_DESCR"] = "Добавить товар в список для сравнения";
$MESS["CATALOG_NOT_AVAILABLE"] = "Нет в наличии";
$MESS["CATALOG_QUANTITY"] = "Количество";
$MESS["CATALOG_QUANTITY_FROM_TO"] = "От #FROM# до #TO#";
$MESS["CATALOG_QUANTITY_FROM"] = "От #FROM#";
$MESS["CATALOG_QUANTITY_TO"] = "До #TO#";
$MESS["CT_BCS_QUANTITY"] = "Количество";
$MESS["CT_BCS_ELEMENT_DELETE_CONFIRM"] = "Будет удалена вся информация, связанная с этой записью. Продолжить?";
$MESS["CATALOG_SUBSCRIBE"] = "Сообщить о поступлении";
$MESS["CATALOG_OFFER_FROM"] = "от ";
?>