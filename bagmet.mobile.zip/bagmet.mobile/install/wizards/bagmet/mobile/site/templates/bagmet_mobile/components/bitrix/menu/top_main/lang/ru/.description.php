<?
$MESS ['MENU_HORIZONT_MULTI_NAME'] = "Р“РѕСЂРёР·РѕРЅС‚Р°Р»СЊРЅРѕРµ РјРµРЅСЋ";
$MESS ['MENU_HORIZONT_MULTI_DESC'] = "Р“РѕСЂРёР·РѕРЅС‚Р°Р»СЊРЅРѕРµ РјРµРЅСЋ";
?>