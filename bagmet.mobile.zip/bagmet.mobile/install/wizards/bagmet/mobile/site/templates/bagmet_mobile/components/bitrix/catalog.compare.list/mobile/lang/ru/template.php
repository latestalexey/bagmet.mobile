<?
$MESS ['CATALOG_LINK'] = "в сравнении";
$MESS ['CATALOG_LINK_TITLE'] = "Сравнить выбранные товары";
$MESS ['CATALOG_LINK_DELETE'] = "Удалить все товары из списка сравнений";
?>