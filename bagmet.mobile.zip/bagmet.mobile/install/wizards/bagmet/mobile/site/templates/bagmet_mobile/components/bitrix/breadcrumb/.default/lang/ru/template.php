<?
$MESS['BREADCRUMB_MAIN'] = 'Главная страница';

?>