<?
$MESS["RECOMMENDED"] = "Аксессуары";
$MESS["SAME"] = "Похожие товары";
?>