<?
$MESS ['AUTH_FORGOT_PASSWORD_1'] = "Если вы забыли пароль, введите логин или E-Mail.<br />Контрольная строка для смены пароля, а также ваши регистрационные данные, будут высланы вам по E-Mail.";
$MESS ['AUTH_GET_CHECK_STRING'] = "Выслать контрольную строку";
$MESS ['AUTH_SEND'] = "Выслать";
$MESS ['AUTH_REMEMBER'] = "Вспомнили пароль - ";
$MESS ['AUTH_AUTH'] = "авторизуйтесь";
$MESS ['AUTH_LOGIN'] = "Логин:";
$MESS ['AUTH_OR'] = "или";
$MESS ['AUTH_EMAIL'] = "E-Mail:";
$MESS ['AUTH_AUTHORIZE'] = "Авторизация";
?>