<?
$MESS["SHOES_FOOTER_CONTACTS"] = "Контакты";
$MESS["SHOES_FOOTER_QR_CODE"] = "Ссылка на эту страницу";
$MESS["SHOES_FOOTER_CATALOG"] = "Каталог товаров";
$MESS["SHOES_FOOTER_PHONE"] = "Телефон:";

$MESS["SHOES_FOOTER_ABOUT"] = "О магазине";
$MESS["SHOES_FOOTER_CATALOG"] = "Каталог товаров";
$MESS["SHOES_FOOTER_CONTACT"] = "Свяжитесь с нами:";
$MESS["SHOES_FOOTER_COMPANY_ABOUT"] = "Подробнее о магазине";
$MESS["SHOES_FOOTER_SOCNET"] = "Мы в соцсетях";
$MESS["SHOES_FOOTER_COMPARE_ADD"] = "Товар добавлен к сравнению";
$MESS["SHOES_FOOTER_COMPARE_LIST"] = "В список сравнения";
$MESS["SHOES_FOOTER_ADD_TO_BASKET"] = "Товар добавлен в корзину";
$MESS["SHOES_FOOTER_GOTO_BACK"] = "Продолжить покупки";
$MESS["SHOES_FOOTER_GOTO_ORDER"] = "Оформить заказ";
$MESS["SHOES_FOOTER_SKU_PROPS"] = "Задайте параметры товара";
$MESS["SHOES_FOOTER_TO_CART"] = "Добавить в корзину";
$MESS["SHOES_FOOTER_CANCEL"] = "Отмена";
$MESS["SHOES_FOOTER_SUBSCRIBE_ADD"] = "Вы подписались на товар";

$MESS["FOOTER_DEVELOPER"] = "Разработано в <a href=\"http://bagmet-studio.ru/\">Веб-студии Багмет Михаила</a>";
$MESS["FOOTER_SKU_BUY"] = "Купить";
$MESS["FOOTER_SKU_SUBSCRIBE_DESCR"] = "<strong>Товара нет в наличии.</strong> Вы можете подписаться на этот товар, нажав кнопку \"Сообщить о поступлении\". Как только товар появится у нас на складе, мы сообщим вам на email.";
$MESS["FOOTER_SKU_SUBSCRIBE"] = "Сообщить о поступлении";
$MESS["FOOTER_SKU_COMPARE_ADD"] = "Добавить в сравнение";

$MESS["FOOTER_ITEM_ADDED_TO_CART"] = "Товар добавлен в корзину";
$MESS["FOOTER_ORDER_ITEM"] = "Оформить заказ";
$MESS["FOOTER_SUBSCRIBED"] = "Вы подписались на товар";
$MESS["FOOTER_ONE_CLICK_BUY"] = "Купить в 1 клик";
$MESS["FOOTER_CATALOG_SUBSCRIBE_INACT"] = "Для подписки на товар<br/>необходимо ";
$MESS["FOOTER_CATALOG_SUBSCRIBE_INACT2"] = "авторизоваться";
$MESS["FOOTER_COMPARE_PATH"] = "Перейти в сравнение";
$MESS["FOOTER_COMPARE_DESCR"] = "Товар добавлен в сравнение";

$MESS["FOOTER_UPPER"] = "Наверх страницы";
?>