<?
$MESS ['MENU_HORIZONT_MULTI_NAME'] = "Horizontal menu";
$MESS ['MENU_HORIZONT_MULTI_DESC'] = "Horizontal menu";
?>