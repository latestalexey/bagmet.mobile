<?
$MESS["CATALOG_LINK"] = "Compare Products";
$MESS["CATALOG_LINK_TITLE"] = "Compare selected products";
$MESS["CATALOG_LINK_DELETE"] = "Reset Comparison Chart";
?>