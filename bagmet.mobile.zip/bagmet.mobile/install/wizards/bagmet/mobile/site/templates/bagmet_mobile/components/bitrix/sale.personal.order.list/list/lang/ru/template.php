<?
$MESS ['P_PAY_SYS'] = "Способ оплаты:";
$MESS ['P_DELIVERY'] = "Доставка:";
$MESS ['STPOL_CUR_ORDERS'] = "Посмотреть текущие заказы";
$MESS ['STPOL_ORDERS_HISTORY'] = "Посмотреть историю заказов";
$MESS ['STPOL_STATUS'] = "Заказы в статусе";
$MESS ['STPOL_ORDER_NO'] = "Заказ №";
$MESS ['STPOL_FROM'] = "от";
$MESS ['STPOL_CANCELED'] = "Заказ отменен";
$MESS ['STPOL_STATUS_T'] = "Статус: ";
$MESS ['STPOL_STATUS_FROM'] = " от ";
$MESS ['STPOL_CONTENT'] = "Состав заказа:";
$MESS ['STPOL_SHT'] = "шт.";
$MESS ['STPOL_DETAILS'] = "Подробнее";
$MESS ['STPOL_REORDER'] = "Повторить заказ (заказать те же товары)";
$MESS ['STPOL_REORDER1'] = "Повторить заказ";
$MESS ['STPOL_CANCEL'] = "Отменить заказ";
$MESS ['STPOL_NO_ORDERS'] = "Заказы не найдены";
$MESS ['STPOL_HINT'] = "Чтобы просмотреть состав заказа, щелкните на его номере.";
$MESS ['STPOL_HINT1'] = "Если Вы обнаружили неточности в этом списке, пожалуйста, напишите в отдел по работе с клиентами.";
$MESS ['STPOL_PAYED_Y'] = "(оплачен)";
$MESS ['STPOL_PAYED_N'] = "(не оплачен)";

$MESS ['STPOL_DETAIL'] = "Подробности заказа";
$MESS ['STPOL_SUM'] = "Сумма к оплате:";
$MESS ['STPOL_PAYED'] = "Оплачен:";
$MESS ['STPOL_Y'] = "Да";
$MESS ['STPOL_N'] = "Нет";

$MESS ['STPOL_F_NAME'] = "Мои заказы:";
$MESS ['STPOL_F_ACTIVE'] = "активные";
$MESS ['STPOL_F_ALL'] = "все";
$MESS ['STPOL_F_COMPLETED'] = "выполненные";
$MESS ['STPOL_F_CANCELED'] = "отмененные";
$MESS ['STPOL_NO_ORDERS_NEW'] = "Отсутствуют заказы для данной категории.";
?>