<?
$MESS["PUP_NULL"] = "Enter a city";
?>