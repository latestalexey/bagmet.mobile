<?
$MESS["SALE_GO_BACK"] = "Если вы не хотите удалять заказ, то можете ";
$MESS["SALE_RECORDS_LIST"] = "вернуться в список заказов";
$MESS["SALE_CANCEL_ORDER3"] = "Внимание, отмена заказа необратима.";
$MESS["SALE_CANCEL_ORDER4"] = "Укажите, пожалуйста, причину отмены заказа";
$MESS["SALE_CANCEL_ORDER_BTN"] = "Отменить заказ";
$MESS["SALE_CANCEL_ORDER"] = "Вы уверены, что хотите отменить <a href=\"#URL_TO#\">заказ ##ID#</a>?";
?>