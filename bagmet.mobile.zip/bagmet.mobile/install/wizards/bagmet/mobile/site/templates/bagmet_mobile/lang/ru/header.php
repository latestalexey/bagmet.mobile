<?
$MESS["SHOES_HEADER_TO_MAIN_PAGE"] = "На главную страницу";
$MESS["SHOES_SEARCH_GOODS"] = "Товары";
$MESS["SHOES_SEARCH_OTHER"] = "Прочее";
$MESS ['SHOES_SEARCH_TITLE'] = "Поиск в каталоге";
?>