<?
$MESS["THEME_DEFAULT"] = "Зеленая";
?>