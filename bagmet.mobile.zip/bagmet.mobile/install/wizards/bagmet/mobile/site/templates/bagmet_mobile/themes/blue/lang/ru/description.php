<?
$MESS["THEME_BLUE"] = "Голубая";
?>