<?
$MESS["SDNW_TITLE"] = "Новости магазина";
$MESS["SDNW_RSS"] = "Подписаться на RSS";
$MESS["SDNW_ALLNEWS"] = "Все новости";
$MESS["NEWS_TITLE"] = "Новости";
?>