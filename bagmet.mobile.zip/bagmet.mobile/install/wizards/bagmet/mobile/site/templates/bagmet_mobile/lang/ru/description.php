<?
$MESS["CSST_TEMPLATE_NAME"] = "Шаблон интернет-магазина";
?>