<?
$MESS["SALE_REFRESH"] = "Refresh";
$MESS["SALE_ORDER"] = "Check out";
$MESS["SALE_NAME"] = "Name";
$MESS["SALE_PROPS"] = "Properties";
$MESS["SALE_PRICE"] = "Price";
$MESS["SALE_PRICE_TYPE"] = "Price type";
$MESS["SALE_QUANTITY"] = "Quantity";
$MESS["SALE_DELETE"] = "Delete";
$MESS["SALE_OTLOG"] = "Hold over";
$MESS["SALE_WEIGHT"] = "Weight";
$MESS["SALE_WEIGHT_G"] = "g";
$MESS["SALE_ITOGO"] = "Total";
$MESS["SALE_REFRESH_DESCR"] = "Click this button to: recalculate, delete or hold products";
$MESS["SALE_ORDER_DESCR"] = "Click this button to check out and order products in your cart";
$MESS["SALE_OTLOG_TITLE"] = "Hold over";
$MESS["SALE_UNAVAIL_TITLE"] = "Currently unavailable";
$MESS["STB_ORDER_PROMT"] = "Click \"Check out\" to complete your order";
$MESS["STB_COUPON_PROMT"] = "If you have special coupon code for discount, please enter it here:";
$MESS["SALE_VAT"] = "Tax:";
$MESS["SALE_VAT_INCLUDED"] = "Tax included:";
$MESS["SALE_TOTAL"] = "Total:";
$MESS["SALE_CONTENT_DISCOUNT"] = "Discount";
$MESS["SALE_DISCOUNT"] = "Discount";
$MESS["SALE_NOTIFY_TITLE"] = "Backordered";
$MESS["SALE_REFRESH_NOTIFY_DESCR"] = "Click this button to remove products.";
?>