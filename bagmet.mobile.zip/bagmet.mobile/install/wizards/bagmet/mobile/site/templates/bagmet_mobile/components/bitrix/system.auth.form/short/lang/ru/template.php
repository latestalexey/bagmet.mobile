<?
$MESS['AUTH_LOGIN'] = 'Войти';
$MESS['AUTH_REGISTER'] = 'Регистрация';
$MESS['AUTH_LOGOUT'] = 'Выйти';
?>