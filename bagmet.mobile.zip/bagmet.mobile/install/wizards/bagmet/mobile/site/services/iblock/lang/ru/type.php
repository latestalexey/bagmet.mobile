<?
$MESS["NEWS_TYPE_NAME"] = "Новости";
$MESS["NEWS_ELEMENT_NAME"] = "Новости";
$MESS["NEWS_SECTION_NAME"] = "Разделы";
$MESS["SERVICES_TYPE_NAME"] = "Сервисы";
$MESS["SERVICES_ELEMENT_NAME"] = "Элементы";
$MESS["SERVICES_SECTION_NAME"] = "Разделы";
$MESS["CATALOG_TYPE_NAME"] = "Каталоги";
$MESS["CATALOG_ELEMENT_NAME"] = "Товары";
$MESS["CATALOG_SECTION_NAME"] = "Разделы";
$MESS["OFFERS_TYPE_NAME"] = "Торговые предложения";
$MESS["OFFERS_ELEMENT_NAME"] = "Предложения";
$MESS["OFFERS_SECTION_NAME"] = "Разделы";
$MESS["BANNER_TYPE_NAME"] = "Баннеры";
$MESS["BANNER_ELEMENT_NAME"] = "Баннер";
$MESS["BANNER_SECTION_NAME"] = "Баннер";
?>