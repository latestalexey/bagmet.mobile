<?
$MESS['UF_BROWSER_TITLE'] = 'Заголовок окна браузера';
$MESS['UF_KEYWORDS'] = 'Ключевые слова';
$MESS['UF_META_DESCRIPTION'] = 'Мета-описание';
?>