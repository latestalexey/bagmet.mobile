<?
$MESS["WZD_OPTION_CATALOG_1"] = "Товар";
$MESS["WZD_OPTION_CATALOG_2"] = "Разместить товар на сайте";
$MESS["WZD_OPTION_CATALOG_3"] = "*Название";
$MESS["WZD_OPTION_CATALOG_4"] = "*Символьный код";
$MESS["WZD_OPTION_CATALOG_5"] = "Изображение";
$MESS["WZD_OPTION_CATALOG_6"] = "Краткое описание";
$MESS["WZD_OPTION_CATALOG_7"] = "Полное описание";
$MESS["WZD_OPTION_CATALOG_8"] = "Значения свойств";
$MESS["WZD_OPTION_CATALOG_9"] = "Разделы каталога";
$MESS["WZD_OPTION_CATALOG_10"] = "Сортировка";
$MESS["WZD_OPTION_CATALOG_20"] = "*Торговый каталог";
$MESS["WZD_OPTION_CATALOG_21"] = "Раздел";
$MESS["WZD_OPTION_CATALOG_22"] = "Разместить раздел на сайте";
$MESS["WZD_OPTION_CATALOG_23"] = "Родительский раздел";
$MESS["WZD_OPTION_CATALOG_24"] = "*Название";
$MESS["WZD_OPTION_CATALOG_25"] = "*Символьный код";
$MESS["WZD_OPTION_CATALOG_26"] = "Изображение";
$MESS["WZD_OPTION_CATALOG_27"] = "Описание";
$MESS["WZD_OPTION_CATALOG_28"] = "Сортировка";
$MESS["WZD_OPTION_CATALOG_30"] = "Разделы";
$MESS["WZD_OPTION_CATALOG_31"] = "Торговые предложения";
$MESS["WZD_OPTION_CATALOG_32"] = "GSM-модуль";
$MESS["WZD_OPTION_CATALOG_33"] = "Объем встроенной памяти";
$MESS["CURRENCY"] = "RUB";
?>