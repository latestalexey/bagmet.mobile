<?
$MESS["WIZ_MENU_TOP_DEFAULT"] = "Hauptmenь";
$MESS["WIZ_MENU_LIGHT_TOP"] = "Hauptmenь";
?>