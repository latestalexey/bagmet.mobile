<?
$MESS["MAIN_OPT_DESCRIPTION"] = "Seitenbeschreibung";
$MESS["MAIN_OPT_KEYWORDS"] = "Schlьsselwцrter";
$MESS["MAIN_OPT_TITLE"] = "Beschriftung des Browserfensters";
$MESS["MAIN_OPT_KEYWORDS_INNER"] = "Promotion keywords";
?>