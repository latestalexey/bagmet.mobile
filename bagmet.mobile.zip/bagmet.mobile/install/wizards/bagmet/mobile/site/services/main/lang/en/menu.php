<?
$MESS["WIZ_MENU_TOP_DEFAULT"] = "Top Menu";
$MESS["WIZ_MENU_LIGHT_TOP"] = "Main Left Menu";
?>