<?
$MESS["STORE_NAME_1"] = "Склад мобильных телефонов №1";
$MESS["STORE_DESCR_1"] = "Самый большой выбор мобильных телефонов";
$MESS["STORE_ADR_1"] = "ул. Миклухо-Маклая д. 18";
$MESS["STORE_GPS_N_1"] = "54.734906";
$MESS["STORE_GPS_S_1"] = "20.542147";
$MESS["STORE_PHONE_1"] = "+74951111111";
$MESS['CAT_STORE_NAME'] = 'Склад';
?>