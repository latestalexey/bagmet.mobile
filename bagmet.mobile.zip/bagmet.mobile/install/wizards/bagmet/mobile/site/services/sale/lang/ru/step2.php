<?
$MESS["SALE_WIZARD_GROUP"] = "Группа местоположений";
$MESS["SALE_WIZARD_MAIL_A"] = "По почте (зона 5)";
$MESS["SALE_WIZARD_MAIL_A_DESC"] = "Тарифы за услуги почтовых и курьерских служб изменяются в зависимости от веса с определенным шагом - обычно 500 или 1000 грамм.";
$MESS["SALE_WIZARD_COUR"] = "Доставка курьером";
$MESS["SALE_WIZARD_COUR_DESCR"] = "Доставка осуществляется в течение дня в удобное для вас время.";
$MESS["SALE_WIZARD_COUR1"] = "Самовывоз";
$MESS["SALE_WIZARD_COUR1_DESCR"] = "Вы можете самостоятельно забрать заказ из нашего магазина.";
$MESS["SALE_WIZARD_SPSR"] = "СПСР-Экспресс";
$MESS["SALE_WIZARD_SPSR_DESCR"] = "Срочная доставка почты";
$MESS["SALE_WIZARD_MAIL"] = "Почта России";
$MESS["SALE_WIZARD_MAIL_DESC"] = "Доставка почтой";
$MESS["SALE_WIZARD_UPS"] = "международная доставка";
$MESS["SALE_WIZARD_VAT"] = "НДС";
$MESS["SALE_WIZARD_ADMIN_SALE"] = "Администраторы интернет-магазина";
$MESS["SALE_WIZARD_ADMIN_SALE_DESCR"] = "Полный доступ к управлению интернет-магазином (в т.ч. заказами) и параметрами торгового каталога (типами цен, наценками, скидками и т.д.).";
$MESS["SALE_WIZARD_CONTENT_EDITOR"] = "Контент-редакторы";
$MESS["SALE_WIZARD_CONTENT_EDITOR_DESCR"] = "Доступ к редактированию информации на сайте.";
$MESS["SUBSCR_1"] = "Новости магазина";
$MESS["SUBSCR_2"] = "Ежедневная рассылка новостей магазина.";
$MESS["REGISTERED_USERS"] = "Зарегистрированные пользователи";
$MESS["TASK_WIZARD_CONTENT_EDITOR"] = "Изменение своего профайла. Управление кешем";
$MESS["TASK_WIZARD_CONTENT_EDITOR_DESC"] = "Разрешено изменять информацию в своем профайле. Управление кешем";
?>