<?
$MESS["WZD_OPTION_BANNER_1"] = "Элемент";
$MESS["WZD_OPTION_BANNER_2"] = "*Название";
$MESS["WZD_OPTION_BANNER_3"] = "*Детальная картинка";
$MESS["WZD_OPTION_BANNER_4"] = "Активность";
$MESS["WZD_OPTION_BANNER_5"] = "Начало активности";
$MESS["WZD_OPTION_BANNER_6"] = "Окончание активности";
$MESS["WZD_OPTION_BANNER_7"] = "Сортировка";
$MESS["WZD_OPTION_BANNER_8"] = "*Символьный код";
$MESS["WZD_OPTION_BANNER_9"] = "Ссылка с баннера";
?>