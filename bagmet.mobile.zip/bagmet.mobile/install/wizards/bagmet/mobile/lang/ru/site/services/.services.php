<?
$MESS["SERVICE_MAIN_SETTINGS"] = "Настройки сайта";
$MESS["SERVICE_IBLOCK"] = "Информационные блоки";
$MESS["SERVICE_SALE_DEMO_DATA"] = "Настройка интернет-магазина";
$MESS["SERVICE_IBLOCK_DEMO_DATA"] = "Добавление каталогов";
$MESS["SERVICE_CATALOG_SETTINGS"] = "Настройка каталога";
$MESS["SERVICE_FORUM"] = "Настройка форума для отзывов";
$MESS["SERVICE_MEDIALIBRARY"] = "Медиабиблиотека";
?>